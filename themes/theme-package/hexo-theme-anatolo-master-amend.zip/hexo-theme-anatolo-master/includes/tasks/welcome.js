const logger = require('hexo-log')();

logger.info(`
=============================================
Welcome from Anatolo!
=============================================`);